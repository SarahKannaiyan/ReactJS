export default function employeeReducer(
  prevState = {
    fetching: false,
    employees: [],
    error: ""
  },
  action
) {
  let newState;

  switch (action.type) {
    case "FETCHING":
      newState = { ...prevState, fetching: true, employees: [], error: "" };
      break;
    case "FETCH_SUCCESS":
      newState = {
        ...prevState,
        fetching: false,
        employees: action.employees,
        error: ""
      };
      break;
    case "FETCH_ERROR":
      newState = {
        ...prevState,
        fetching: false,
        employees: [],
        error: action.error
      };
      break;
    default:
      newState = { ...prevState };
      break;
  }

  return newState;
}
