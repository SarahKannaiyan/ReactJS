import axios from "axios";

export default function listEmployeeAction() {
  return function(dispatch) {
    dispatch({
      type: "FETCHING"
    });
    axios
      .get("http://localhost:3004/employees")
      .then(response => {
        dispatch({
          type: "FETCH_SUCCESS",
          employees: response.data
        });
      })
      .catch(error => {
        dispatch({
          type: "FETCH_ERROR",
          employeeS: error.message
        });
      });
  };
}

export function addEmployeeAction(emp) {
  return function(dispatch) {
    axios
      .post("http://localhost:3004/employees", emp)
      .then(response => {
        dispatch(listEmployeeAction());
      })
      .catch(error => {
        console.log("error", error);
      });
  };
}

export function deleteEmployeeAction(id) {
  return function(dispatch) {
    axios
      .delete(`http://localhost:3004/employees/${id}`)
      .then(response => {
        dispatch(listEmployeeAction());
      })
      .catch(error => {
        console.log("error", error);
      });
  };
}

export function modifyEmployeeAction(emp, id) {
  return function(dispatch) {
    axios
      .put(`http://localhost:3004/employees/${id}`, emp)
      .then(response => {
        dispatch(listEmployeeAction());
      })
      .catch(error => {
        console.log("error", error);
      });
  };
}
