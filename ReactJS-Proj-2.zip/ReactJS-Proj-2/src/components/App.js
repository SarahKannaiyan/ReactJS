import React from "react";
import { connect } from "react-redux";

import AddRow from "./AddRow";
import DisplayRow from "./DisplayRow";
import Header from "./Header";
import listEmployeeAction from "../actions/employeeActions";


class App extends React.Component {
  constructor(props) {
    super(props);
    this.changeEditMode = this.changeEditMode.bind(this);
    this.state = {
      editMode: false,
      selectedEmployee:[]
    };
  }
  componentDidMount() {
    this.props.dispatch(listEmployeeAction());
  }
  changeEditMode(emp) {
    this.setState({editMode:true,selectedEmployee:emp})
    console.log("selectedEmployee:",emp);
  }
  render() {
    var empJSX = this.props.employees.map(element => {
      return (
        <DisplayRow
          key={element.id}
          employee={element}
          dispatch={this.props.dispatch}
          changeEditMode={this.changeEditMode}
        />
      );
    });

    return (
      <main className="main">
        <Header />
        <section className="content">
          <form action="">
            <div>
              <table id="tab">
                <thead>
                  <tr>
                    <th>Id</th>
                    <th>Name</th>
                    <th>Phone</th>
                    <th>Email</th>
                    <th>Department</th>
                    <th>&nbsp;</th>
                  </tr>
                </thead>
                <tbody>
                  <AddRow
                    dispatch={this.props.dispatch}
                    editMode={this.state.editMode}
                    employee={this.state.employee}
                  />
                  {empJSX[0] ? (
                    empJSX
                  ) : (
                    <tr>
                      <td colSpan="6">
                        <h1>
                          Sorry! unable to fetch Employee List at this point in
                          time
                        </h1>
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </form>
        </section>
      </main>
    );
  }
}

function mapStateToProps(state) {
  console.log("employees:", state.employees);
  return {
    employees: state.employees
  };
}
const AppContainer = connect(mapStateToProps)(App);
export default AppContainer;
