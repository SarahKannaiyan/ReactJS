import React from "react";
import axios from "axios";

import { addEmployeeAction } from "../actions/employeeActions";
import { modifyEmployeeAction } from "../actions/employeeActions";

class AddRow extends React.Component {
  constructor(props) {
    super(props);
    this.addEmployee = this.addEmployee.bind(this);
    this.state = {
      departments: []
    };
    console.log(props.employee)
  }
  componentDidMount() {
    axios
      .get("http://localhost:3004/departments")
      .then(response => {
        this.setState({ departments: response.data });
      })
      .catch(error => {
        console.log("Error: ", error);
      });
      
      
  }
  addEmployee(ev) {
    const submitValues = {
      name: this.name.value,
      phone: this.phone.value,
      email: this.email.value,
      department: this.department.value
    };
    console.log(submitValues);
    this.props.dispatch(addEmployeeAction(submitValues));
    this.name.value = "";
    this.phone.value = "";
    this.email.value = "";
    this.department.value = "Select Department";
  }

  modifyEmployee(ev) {
    const submitValues = {
      id: this.id.value,
      name: this.name.value,
      phone: this.phone.value,
      email: this.email.value,
      department: this.department.value
    };
    console.log(submitValues);
    this.props.dispatch(modifyEmployeeAction(submitValues));
    this.name.value = "";
    this.phone.value = "";
    this.email.value = "";
    this.department.value = "Select Department";
  }

  render() {
    const deptJSX = this.state.departments.map(dept => (
      <option key={dept.id}>{dept.name}</option>
    ));
    return (
      <tr style={{ backgroundColor: "lightpink" }}>
        <td>&nbsp;</td>
        <td>
          <input
            type="text"
            ref={node => {
              this.name = node;
            }}
          />
        </td>
        <td>
          <input
            type="text"
            ref={node => {
              this.phone = node;
            }}
          />
        </td>
        <td>
          <input
            type="text"
            ref={node => {
              this.email = node;
            }}
          />
        </td>
        <td>
          <select
            ref={node => {
              this.department = node;
            }}
          >
            <option>Select Department</option>
            {deptJSX}
          </select>
        </td>
        <td>
           {
                !this.props.editMode?(<button
                    type="button"
                    className="small-button"
                    onClick={this.addEmployee}
                  >
                    Add
                  </button>):(
                      <div>
                  <button type="button" className="small-button" onClick={this.addEmployee}>Modify</button>
                  <button type="button" className="small-button" onClick={this.addEmployee}>Cancel</button>
                  </div>
                  )
                  }
         
        </td>
      </tr>
    );
  }
}

// AddRow.defaultProps={
//     display:false
// }

export default AddRow;
