import React from "react";
import { deleteEmployeeAction } from "../actions/employeeActions";

function DisplayRow(props) {
  const { employee, dispatch } = props;
  return (
    <tr>
      <td>{employee.id}</td>
      <td>{employee.name}</td>
      <td>{employee.phone}</td>
      <td>{employee.email}</td>
      <td>{employee.department}</td>
      <td>
        <button
          type="button"
          className="small-button"
          onClick={() => {
            props.changeEditMode(employee);
          }}
        >
          Edit
        </button>
        <button
          type="button"
          className="small-button"
          onClick={() => {
            dispatch(deleteEmployeeAction(employee.id));
          }}
        >
          Delete
        </button>
      </td>
    </tr>
  );
}

export default DisplayRow;
