// var employeeDetails=[
//     {employeeId:1,fullName:"john",email:"john@gmail.com",mobileNo:"9000520840",dateofJoin:"12/02/2018",Department:'IT',CLB:2},
//     {employeeId:2,fullName:"john1",email:"john1@gmail.com",mobileNo:"9000520841",dateofJoin:"12/01/2018",Department:'IT',CLB:3},
//     {employeeId:2,fullName:"john2",email:"john2@gmail.com",mobileNo:"9000520842",dateofJoin:"12/03/2018",Department:'IT',CLB:7},
//     {employeeId:2,fullName:"john3",email:"john3@gmail.com",mobileNo:"9000520843",dateofJoin:"12/02/2018",Department:'IT',CLB:4},
// ]
    var ary=[];
$("tr.table").click(function() {
    var tableData = $(this).children("td").map(function(a,b) {
        return $(this).text();
    }).get();
    ary.push({ EmployeeId: $.trim(tableData[0]), FullName: $.trim(tableData[1]),Email: $.trim(tableData[2]),MobileNumber:$.trim(tableData[3]),Doj:$.trim(tableData[4]) });
    localStorage.setItem("employeeData",tableData);  
    localStorage.setItem("employeeId",$.trim(tableData[0]));
    location.href = "Login.html";
});

