/**
 * @author Prakash Kumar
 */
function setGender(val){
    document.getElementById('selectedGender').innerHTML=val;
}

function checkEnableSubmit(){
    if(document.getElementById('apply').checked == true && document.getElementById('username').value !="")
    {
        document.getElementById('submit').disabled = false;
    }
    else{
        document.getElementById('submit').disabled = true;
    }
}

function documentreset(){
    document.getElementById('username').value ="";
    document.getElementById('firstname').value ="";
    enableReset();
}
function enableReset(){
    if(document.getElementById('username').value !="" && document.getElementById('firstname').value !="")
    {
        document.getElementById('reset').disabled = false;
    }
    else{
        document.getElementById('reset').disabled = true;
    }
    
}

