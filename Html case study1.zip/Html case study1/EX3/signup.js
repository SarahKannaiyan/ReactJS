function setGender(val){
    document.getElementById('selectedGender').innerHTML=val;
}

function documentreset(){
    document.getElementById('username').value ="";
    document.getElementById('firstName').value ="";
    enableReset();
}
function checkEnableSubmit(){
    if(document.getElementById('applycondition').checked == true && document.getElementById('username').value !="")
    {
        document.getElementById('submit').disabled = false;
    }
    else{
        document.getElementById('submit').disabled = true;
    }
}

function enableReset(){    
    if(document.getElementById('username').value !="" && document.getElementById('firstName').value !="")
    {
        document.getElementById('reset').disabled = false;
    }
    else{
        document.getElementById('reset').disabled = true;
    }
    
}