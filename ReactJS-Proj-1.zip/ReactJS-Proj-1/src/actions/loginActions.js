export function loginAction(){
    return {type:"LOGIN"}
}

export function logoutAction(){
    return {type:"LOGOUT"}
}

