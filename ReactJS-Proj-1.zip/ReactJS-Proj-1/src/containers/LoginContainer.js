import { connect } from "react-redux";

import Login from "../components/Login";

const LoginContainer = connect()(Login);

export default LoginContainer;
