import React from "react";
import { Redirect } from "react-router-dom";
import axios from "axios";

class UpdateDepartment extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      created: false,
      mandatoryNameError: "",
      deptId: ""
    };

    this.submitForm = this.submitForm.bind(this);
  }

  componentDidMount() {
    let department = JSON.parse(localStorage.getItem("department"));
    console.log("departmentlist", department);
    this.deptName.value = department.name;
    this.setState({ deptId: department.id });
  }

  submitForm(ev) {
    const deptName = this.deptName.value;

    if (deptName === "") {
      this.setState({ mandatoryNameError: "Required" });
      return;
    }

    this.setState({ mandatoryNameError: "" });

    const submitValues = {
      name: deptName
    };

    axios
      .put(
        `http://localhost:3004/departments/${this.state.deptId}`,
        submitValues
      )
      .then(response => {
        this.setState({ created: true });
      })
      .catch(error => {
        console.log("Error: ", error);
      });
  }

  render() {
    if (this.state.created === true) {
      return <Redirect to="department-list" />;
    }

    return (
      <section className="content">
        <h1>Update Department</h1>
        <form>
          <div className="form-input">
            <label htmlFor="dname">Name:</label>
            <input
              name="dname"
              type="text"
              ref={node => {
                this.deptName = node;
              }}
            />
            &nbsp;
            <span style={{ color: "maroon" }}>
              {this.state.mandatoryNameError}
            </span>
          </div>

          <div className="form-input">
            <input type="button" value="Update" onClick={this.submitForm} />
            <input type="reset" value="Reset" />
          </div>
        </form>
      </section>
    );
  }
}

export default UpdateDepartment;
