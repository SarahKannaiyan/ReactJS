//uncontrolled components example

import React from "react";

class Login1 extends React.Component {
  constructor(props) {
    super(props);
    //this.un = React.createRef();
   // this.pwd = React.createRef();
    this.submitControlled = this.submitControlled.bind(this);
  }
  submitControlled() {
    const submitValues = {
      uname: this.un.value,
      pword: this.pwd.value
    };
    console.log(submitValues);
  }
  render() {
    return (
      <section className="content">
        <h1>Login</h1>
        <form action="">
          <div className="form-input">
            <label>Username:</label>
            <input type="text" name="un" ref={node=>{this.un=node}} defaultValue="test"/>
          </div>
          <div className="form-input">
            <label>Password:</label>
            <input type="password" name="pwd" ref={node=>{this.pwd=node}} defaultValue="test"/>
          </div>

          <div className="form-input">
            <input
              type="button"
              value="Login"
              onClick={this.submitControlled}
            />
            <input type="button" value="Reset" />
          </div>
        </form>
      </section>
    );
  }
}

export default Login1;
