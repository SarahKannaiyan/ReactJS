import React from "react";
import { Route, Switch } from "react-router-dom";

import LoginContainer from "../containers/LoginContainer";
import Logout from "./Logout";

import EmployeeList from "./Employee/EmployeeList";
import AddEmployee from "./Employee/AddEmployee";
import ModifyEmployee from "./Employee/ModifyEmployee";
import DepartmentList from "./Department/DepartmentList";
import AddDepartment from "./Department/AddDepartment";
import UpdateDepartment from "./Department/UpdateDepartment";

import PrivateRoute from "./PrivateRoute";
class Content extends React.Component {
  render() {
    return (
      <div>
        <Switch>
          <Route exact path="/" component={LoginContainer} />
          <Route eaxct path="/login" component={LoginContainer} />
          <Route path="/employee-list" component={EmployeeList} />
          <Route path="/add-employee" component={AddEmployee} />
          <Route path="/modify-employee" component={ModifyEmployee} />
          <Route path="/department-list" component={DepartmentList} />
          <Route path="/add-department" component={AddDepartment} />
          <Route path="/modify-department" component={UpdateDepartment} />
          <PrivateRoute path="/logout" component={Logout} />
        </Switch>
      </div>
    );
  }
}

export default Content;
