import React from "react";
// import {Link} from 'react-router-dom';
import { Link } from "react-router-dom";
class Nav extends React.Component {
  render() {
    return (
      <nav className="nav">
        <div>
          <Link to="./department-list">Department</Link>
        </div>
        <div>
          <Link to="./employee-list">Employee</Link>
        </div>
        <div>
          <Link to="./login">Logout</Link>
        </div>
      </nav>
    );
  }
}

export default Nav;
