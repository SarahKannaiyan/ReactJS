import React from "react";
import axios from "axios";
import { Link } from "react-router-dom";

class EmployeeList extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      employees: [],
      idToDelete: 0,
    };

    this.employeeSelected = this.employeeSelected.bind(this);
    this.deleteSelected = this.deleteSelected.bind(this);
    this.updateSelected=this.updateSelected.bind(this);
  }

  employeeSelected(employee) {
    localStorage.setItem("employee",JSON.stringify(employee));
    this.setState({ idToDelete: employee.id });
  }
  deleteSelected() {
    if (this.state.idToDelete === 0) {
      alert("Select a record to delete!");
      return;
    }
    axios
      .delete(`http://localhost:3004/employees/${this.state.idToDelete}`)
      .then(response => {
        this.setState({ idToDelete: 0 });
        return axios.get("http://localhost:3004/employees");
      })
      .then(response => {
        // handle success
        this.setState({ employees: response.data });
      })
      .catch(error => {
        console.log("Error: ", error);
      });
  }

  updateSelected(){
  
  
  }

  componentDidMount() {
    // api call
    axios
      .get("http://localhost:3004/employees")
      .then(response => {
        // handle success
        this.setState({ employees: response.data });
      })
      .catch(error => {
        // handle error
        console.log("Error: ", error);
      });
  }

  render() {
    const employeeListJSX = this.state.employees.map(element => (
      <tr key={element.id}>
        <td>{element.id}</td>
        <td>{element.name}</td>
        <td>{element.email}</td>
        <td>{element.phone}</td>
        <td>{element.department}</td>
        <td>
          <input
            name="dept"
            type="radio"
            onChange={() => {
              this.employeeSelected(element);
            }}
          />
        </td>
      </tr>
    ));

    return (
      <section className="content">
        <h1>Employees</h1>
        <form action="">
          <div>
            <Link to="/add-employee">
              <input type="button" value="Create" />
            </Link>
            <Link to="/modify-employee">
            <input type="button" value="Update" />
            </Link>
           
            
            <input type="button" value="Delete" onClick={this.deleteSelected} />
          </div>
          <div>
            <table id="tab">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Email</th>
                  <th>Phone</th>
                  <th>Department</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>

              <tbody>{employeeListJSX}</tbody>
            </table>
          </div>
        </form>
      </section>
    );
  }
}

export default EmployeeList;
