import React from "react";
import { Redirect } from "react-router-dom";
import axios from "axios";

class ModifyEmployee extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      departmentList: [],
      created: false,
      mandatoryNameError: "",
      deptid: "",
      deptName: "",
      employee: [],
      selectedValue:"Select Department"
    };

    this.submitForm = this.submitForm.bind(this);
    // this.handleChange = this.handleChange.bind(this);
  }
  componentDidMount() {
    // api call
    axios
      .get("http://localhost:3004/departments")
      .then(response => {
        // handle success
        this.setState({ departmentList: response.data });
      })
      .catch(error => {
        // handle error
        console.log("Error: ", error);
      });
    console.log("employee:", JSON.parse(localStorage.getItem("employee")));
    //      this.setState({employee:JSON.parse(localStorage.getItem("employee"))});
    let employee = JSON.parse(localStorage.getItem("employee"));
    this.setState({ deptid: employee.id });
    this.ename.value = employee.name;
    this.email.value = employee.email;
    this.phone.value = employee.phone;
    //this.department.value = "Finance";
    this.state.selectedValue=employee.department;
    console.log(employee.department);
  }

  //   handleChange(ev) {
  //     this.state.deptid = ev.target.value;
  //     var value = this.state.departmentList.filter(function(item) {
  //       return item.id == ev.target.value;
  //     });
  //     this.state.deptName = value[0].name;
  //   }
  submitForm() {
    const submitValues = {
      name: this.ename.value,
      email: this.email.value,
      phone: this.phone.value,
      department: this.department.value
    };
    console.log(submitValues);

    axios
      .put(`http://localhost:3004/employees/${this.state.deptid}`, submitValues)
      .then(response => {
        this.setState({ created: true });
      })
      .catch(error => {
        console.log("Error: ", error);
      });
  }

  render() {
    if (this.state.created === true) {
      return <Redirect to="employee-list" />;
    }

    const employeeListJSX = this.state.departmentList.map(element => (
      <option value={element.id}>{element.name}</option>
    ));
    const deptJSX = this.state.departmentList.map(element => (
      <option key={element.id}>{element.name}</option>
    ));
    return (
      <section className="content">
        <h1>Create New Employee</h1>
        <form>
          <table>
            <tbody>
              <tr>
                <td style={{ width: "50%" }}>
                  <label htmlFor="Name">
                    <b>Name : </b>
                  </label>
                  &nbsp;
                  <input
                    name="Name"
                    type="text"
                    ref={node => (this.ename = node)}
                  />
                </td>
              </tr>
              <tr>
                <td style={{ width: "30%" }}>
                  <label htmlFor="email">
                    <b>Email : </b>
                  </label>
                  &nbsp;
                  <input
                    name="email"
                    type="text"
                    ref={node => {
                      this.email = node;
                    }}
                  />
                </td>
              </tr>
              <tr>
                <td style={{ width: "30%" }}>
                  <label htmlFor="phone">
                    <b>Phone : </b>
                  </label>
                  &nbsp;
                  <input
                    name="phone"
                    type="text"
                    ref={node => {
                      this.phone = node;
                    }}
                  />
                </td>
              </tr>
              <tr>
                <td style={{ width: "30%" }}>
                  <label htmlFor="">
                    <b>Department : </b>
                  </label>
                  &nbsp;
                  <select value={this.state.selectedValue}
                    name="department"
                    ref={node => {
                      this.department = node;
                    }}
                  >
                    <option>Select Department</option>
                    {deptJSX}
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  <input
                    type="button"
                    value="Modify"
                    onClick={this.submitForm}
                  />
                </td>
                <td>
                  <input type="reset" value="Reset" />
                </td>
              </tr>
            </tbody>
          </table>
        </form>
      </section>
    );
  }
}

export default ModifyEmployee;
