function previous() {
  window.location.href = "employeeList.html";
}

function reset() {
  var element = document.getElementsByName("user");
  for (var i = 0; i < element.length; i++) {
    element[i].disabled = true;
  }
  if (document.getElementById("username") != undefined) {
    var url = new URLSearchParams(window.location.search);
    document.getElementById("username").value = url.get("user");
  }

  window.employeeList = {
    Steve: "E23050",
    Tony: "E23051",
    Bruce: "E23052",
    Nick: "E23053",
    Phil: "E23054"
  };
  window.employeeDetails = {
    E23050: {
      EmployeeId: "E23050",
      DateJoined: "01/01/1955",
      FullName: "Steve Rogers",
      Department: "ADM",
      Email: "SteveRogers@Avengers.com",
      Mobile: "001-623423523",
      AvailableLeave: 10,
      MangerId: "E23053"
    },
    E23051: {
      EmployeeId: "E23051",
      DateJoined: "02/02/2010",
      FullName: "Tony Stark",
      Department: "Java",
      Email: "TonyStark@Avengers.com",
      Mobile: "001-623423523",
      AvailableLeave: 12,
      MangerId: "E23054"
    },
    E23052: {
      EmployeeId: "E23052",
      DateJoined: "03/03/2008",
      FullName: "Bruce Banner",
      Department: "ADM",
      Email: "BruceBanner@Avengers.com",
      Mobile: "001-623423523",
      AvailableLeave: 14,
      MangerId: "E23054"
    },
    E23053: {
      EmployeeId: "E23053",
      DateJoined: "04/04/1950",
      FullName: "Nick Fury",
      Department: "Java",
      Email: "NickFury@Avengers.com",
      Mobile: "001-623423523",
      AvailableLeave: 6,
      MangerId: "0"
    },
    E23054: {
      EmployeeId: "E23054",
      DateJoined: "05/05/1952",
      FullName: "Phil Coulson",
      Department: "Java",
      Email: "PhilCoulson@Avengers.com",
      Mobile: "001-623423523",
      AvailableLeave: 5,
      MangerId: "E23053"
    }
  };

  var leaveDetailsInit = localStorage["LeaveDetails"];
  window.leaveDetails =
    leaveDetailsInit == undefined ? {} : JSON.parse(leaveDetailsInit);
  // window.leaveDetails = {
  //     '101': [{
  //         "LeaveId": "L001",
  //         "NumberOfDays": 1,
  //         "StartDate": '10/10/2017',
  //         "EndDate": '11/10/2017',
  //         "LeaveType": "Earned Leave",
  //         "Status": "Approved",
  //         "Reason": "EL",
  //         "AppliedOn": '09/10/2017',
  //         "ManagerComments":"Approved"
  //     },{
  //         "LeaveId": "L002",
  //         "NumberOfDays": 1,
  //         "StartDate": '14/10/2018',
  //         "EndDate": '14/10/2018',
  //         "LeaveType": "Earned Leave",
  //         "Status": "Approved",
  //         "Reason": "EL",
  //         "AppliedOn": '09/10/2017',
  //         "ManagerComments":"Approved"
  //     }]
  // };

  if (document.getElementById("employeeid") != undefined) {
    var username = new URLSearchParams(window.location.search).get("username");
    var emp = employeeDetails[employeeList[username]];
    setValue("employeeid", emp.EmployeeId);
    setValue("fullname", emp.FullName);
    setValue("email", emp.Email);
    setValue("mobile", emp.Mobile);
    setValue("datejoined", emp.DateJoined);
    setValue("department", emp.Department);
    setValue("leavebalance", emp.AvailableLeave);

    if (emp.MangerId != 0) {
      setValue("memployeeid", employeeDetails[emp.MangerId].EmployeeId);
      setValue("mfullname", employeeDetails[emp.MangerId].FullName);
      setValue("memail", employeeDetails[emp.MangerId].Email);
      setValue("mmobile", employeeDetails[emp.MangerId].Mobile);
    }

    var item = leaveDetails[employeeList[username]];
    var stringbuilder = "";
    var table, tr, th, td;

    if (item != undefined) {
      for (var i = 0; i < item.length; i++) {
        tr = document.createElement("tr");
        td = document.createElement("td");
        td.innerText = item[i]["LeaveId"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["NumberOfDays"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["StartDate"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["EndDate"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["LeaveType"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["Status"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["Reason"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["AppliedOn"];
        tr.append(td);
        td = document.createElement("td");
        td.innerText = item[i]["ManagerComments"];
        tr.append(td);
        document.getElementById("leaveDetails").append(tr);
      }
    }

    item = {};

    if (employeeDetails[employeeList[username]].MangerId == 0) {
      for (var i in employeeDetails) {
        if (employeeDetails[i].MangerId != 0 && leaveDetails[i] != undefined) {
          item[i] = leaveDetails[i];
        }
      }
    } else {
      for (var i in employeeDetails) {
        if (
          employeeDetails[i].MangerId == employeeList[username].EmployeeId &&
          leaveDetails[i] != undefined
        ) {
          //item.push(leaveDetails[i]);
          item[i] = leaveDetails[i];
        }
      }
    }
    //item = leaveDetails[employeeList[username]];
    if (item != undefined) {
      for (i in item) {
        table = document.createElement("table");
        table.style = "width:1000px;";
        tr = document.createElement("tr");
        th = document.createElement("th");
        th.colSpan = 2;
        th.innerText = "Employee ID";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = employeeDetails[i].EmployeeId;
        tr.append(th);
        th = document.createElement("th");
        th.colSpan = 2;
        th.innerText = "Employee Name";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = employeeDetails[i].FullName;
        tr.append(th);
        th = document.createElement("th");
        th.colSpan = 1;
        th.innerText = "Employee Leave Balance";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = employeeDetails[i].AvailableLeave;
        tr.append(th);

        table.append(tr);

        tr = document.createElement("tr");
        th = document.createElement("th");
        th.rowSpan = item[i].length+1;
        th.style = "width:50px;";
        th.innerText = "";
        tr.append(th);

        th = document.createElement("th");
        th.innerText = "Leave ID";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = "Number of days";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = "Start Date";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = "End Date";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = "Leave Type";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = "Status";
        tr.append(th);
        th = document.createElement("th");
        th.innerText = "Reason";
        tr.append(th);
        table.append(tr);

        var attr;
        //////////////
        for (var j = 0; j < item[i].length; j++) {
          tr = document.createElement("tr");
          td = document.createElement("td");
          td.innerText = item[i][j]["LeaveId"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          td = document.createElement("td");
          td.innerText = item[i][j]["NumberOfDays"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          td = document.createElement("td");
          td.innerText = item[i][j]["StartDate"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          td = document.createElement("td");
          td.innerText = item[i][j]["EndDate"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          td = document.createElement("td");
          td.innerText = item[i][j]["LeaveType"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          td = document.createElement("td");
          td.innerText = item[i][j]["Status"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          td = document.createElement("td");
          td.innerText = item[i][j]["Reason"];
          td.setAttribute("class", "borderme");
          td.setAttribute(
            "onclick",
            'leaveSelected("' + item[i][j]["LeaveId"] + '", this)'
          );
          tr.append(td);
          table.append(tr);
        }
        document.getElementById("reportDiv").append(table);
      }
    }
  }

  if (document.getElementById("startdate") != undefined) {
    var username = new URLSearchParams(window.location.search).get("username");
    document.getElementById("usernameDashboard").value = username;
    // document.getElementById('startdate').valueAsDate = new Date();
    // document.getElementById('enddate').value = new Date().toISOString().substr(0, 10);

    // var start  = document.getElementById('startdate').value;
    // var end  = document.getElementById('startdate').value;
    // document.getElementById('numberofdays').value = new Date(start) - new Date(end) + 1;
  }
}

function startchanged(ev) {
  console.log(ev);
  var start = document.getElementById("startdate").valueAsDate;
  var end = document.getElementById("enddate").valueAsDate;
  
  if (start != null) {
    if (Math.ceil((new Date(start).getTime() - new Date().getTime()) / (1000 * 3600 * 24))) {
      //if start date is less than today
      alert("start date cannot be less than today");
      ev.preventDefault();
      return false;
    }
  }
  if (end != null) {
    if (Math.ceil((new Date(start).getTime() - new Date().getTime()) / (1000 * 3600 * 24))) {
      //if start date is less than today
      alert("end date cannot be less than today");
      ev.preventDefault();
      return false;
    }
  }

  if (start != null && end != null) {
    if (new Date(end) - new Date(start) < 0) {
      alert("end date cannot be lesser than start date");
      if(ev !=null && ev!=undefined)
      ev.preventDefault();
      return false;
    } else {
      document.getElementById("numberofdays").value =
        (new Date(end) - new Date(start)) / (3600 * 24 * 1000) + 1;
    }
  }
}
function endchanged() {}

reset();

function login(user) {
  document.querySelector("input[value='" + user + "']").disabled = false;
  document.getElementById("frmEmployee").submit();
}

function setValue(selector, value) {
  document.getElementById(selector).innerHTML = value;
}

function checkValue(selector, value) {
  return document.getElementById(selector).value.trim() == value.trim();
}

function newapplyLeave() {
  window.location.href =
    "applyleave.html?username=" +
    new URLSearchParams(window.location.search).get("username");
}

function cancelLeave() {
  window.location.href =
    "employeeDashboard.html?username=" +
    new URLSearchParams(window.location.search).get("username");
}

function applyNewLeave() {
 
    var start = document.getElementById("startdate").valueAsDate;
  var end = document.getElementById("enddate").valueAsDate;
  
  if (start != null) {
    if (Math.ceil((new Date(start).getTime() - new Date().getTime()) / (1000 * 3600 * 24))) {
      //if start date is less than today
      alert("start date cannot be less than today");
      return false;
    }
  }
  if (end != null) {
    if (Math.ceil((new Date(start).getTime() - new Date().getTime()) / (1000 * 3600 * 24))) {
      //if start date is less than today
      alert("end date cannot be less than today");
      return false;
    }
  }

  if (start != null && end != null) {
    if (new Date(end) - new Date(start) < 0) {
      alert("end date cannot be lesser than start date");
      return false;
    } else {
      document.getElementById("numberofdays").value =
        (new Date(end) - new Date(start)) / (3600 * 24 * 1000) + 1;
    }
  }

  //Date Validation
  var start = document.getElementById("startdate").valueAsDate;
  if (start == null) {
    alert("start date not selected");
    return false;
  }
  var end = document.getElementById("enddate").valueAsDate;
  if (end == null) {
    alert("end date not selected");
    return false;
  }
  var numberofdaysSelected = document.getElementById("numberofdays").value;

  var calculatedDays = (document.getElementById("numberofdays").value =
    (new Date(end) - new Date(start)) / (3600 * 24 * 1000) + 1);
  if (calculatedDays != numberofdaysSelected) {
    alert("Number of days is not matching selected dates difference");
    return false;
  }
  // var leavereasontext  = document.getElementById('leavereason').value.trim();
  // if(leavereasontext ==""){
  //     alert('Leave reason is required to apply leave');
  //     return false;
  // }
  if (localStorage["LeaveDetails"] == undefined) {
    localStorage["LeaveDetails"] = "{}";
  }
  if (localStorage["LeaveDetails"] != undefined) {
    var username = new URLSearchParams(window.location.search).get("username");
    if (username != null) {
      var empId = employeeDetails[employeeList[username]].EmployeeId;
      var existingVal = [];
      if (JSON.parse(localStorage["LeaveDetails"])[empId] == undefined) {
        existingVal = [];
      } else {
        existingVal = JSON.parse(localStorage["LeaveDetails"])[empId];
      }
      var leaveCount = 0;
      var totalLeaves = JSON.parse(localStorage["LeaveDetails"]);
      for (var i in totalLeaves) {
        if (totalLeaves[i] != undefined && totalLeaves[i] != null) {
          leaveCount += totalLeaves[i].length;
        }
      }

      var _noofdays = document.getElementById("numberofdays").value;
      var _startdate = document.getElementById("startdate").value;
      var _enddate = document.getElementById("enddate").value;
      var _leavereason = document.getElementById("leavereason").value;
      var _leaveTypeSelect = document.getElementById("leaveTypeSelect").value;

      var leaveDetailsVal = {
        EmployeeId: empId,
        LeaveId: "L" + leaveCount,
        NumberOfDays: _noofdays,
        StartDate: _startdate,
        EndDate: _enddate,
        LeaveType: _leaveTypeSelect,
        Status: "Pending Approval",
        Reason: _leavereason,
        AppliedOn: new Date().toISOString().substr(0, 10),
        ManagerComments: ""
      };
      //
      existingVal.push(leaveDetailsVal);

      var currentValue = JSON.parse(localStorage["LeaveDetails"]);
      currentValue[empId] = existingVal;
      localStorage["LeaveDetails"] = JSON.stringify(currentValue);
    }
  } else {
  }

  var leaveDetailsInit = localStorage["LeaveDetails"];
  window.leaveDetails =
    leaveDetailsInit == undefined ? {} : JSON.parse(leaveDetailsInit);

  alert("Leave applied successfully");
  window.location.href =
    "employeeDashboard.html?username=" +
    new URLSearchParams(window.location.search).get("username");
}

// function processLeave(data) {
//   leaveid = data.getAttribute("data-leaveid");
//   window.location.href =
//     "approveLeave.html?leaveid=" +
//     leaveid +
//     "&username=" +
//     new URLSearchParams(window.location.search).get("username");
// }

function approveLeave() {
  var username = new URLSearchParams(window.location.search).get("username");
  var leaveid = new URLSearchParams(window.location.search).get("leaveid");
  var leaveDetailsById = leaveDetails[leaveid];
  document.getElementById("usernameDashboard").value = username;
  for (var i in leaveDetails) {
    for (var j in leaveDetails[i]) {
      if (leaveDetails[i][j].LeaveId == leaveid) {
        leaveDetails[i][j].ManagerComments = document.getElementById(
          "lapprovecomment"
        ).value;
        leaveDetails[i][j].Status = "Approved";
        leaveDetails[i][j].AvailableLeave =
          parseInt(leaveDetails[i][j].AvailableLeave) - 1;

        localStorage["LeaveDetails"] = JSON.stringify(leaveDetails);
        return true;
      }
    }
  }
}

function denyLeave() {
  if (checkValue("lapprovecomment", "")) {
    alert("Comments is mandatory for denying leave");
    return false;
  }

  var username = new URLSearchParams(window.location.search).get("username");
  var leaveid = new URLSearchParams(window.location.search).get("leaveid");
  var leaveDetailsById = leaveDetails[leaveid];
  document.getElementById("usernameDashboard").value = username;
  for (var i in leaveDetails) {
    for (var j in leaveDetails[i]) {
      if (leaveDetails[i][j].LeaveId == leaveid) {
        leaveDetails[i][j].ManagerComments = document.getElementById(
          "lapprovecomment"
        ).value;
        leaveDetails[i][j].Status = "Denied";
        localStorage["LeaveDetails"] = JSON.stringify(leaveDetails);
        return true;
      }
    }
  }
}

function fillLeaveDetails() {
  var username = new URLSearchParams(window.location.search).get("username");
  var leaveid = new URLSearchParams(window.location.search).get("leaveid");
  var leaveDetailsById = leaveDetails[leaveid];
  document.getElementById("usernameDashboard").value = username;
  for (var i in leaveDetails) {
    for (var j in leaveDetails[i]) {
      if (leaveDetails[i][j].LeaveId == leaveid) {
        setValue(
          "lemployeeid",
          leaveDetails[i][j].EmployeeId
          //employeeDetails[employeeList[username]].EmployeeId
        );
        setValue(
          "lemployeename",
          employeeDetails[leaveDetails[i][j].EmployeeId].FullName
        );
        setValue(
          "lleavebalance",
          employeeDetails[leaveDetails[i][j].EmployeeId].AvailableLeave
        );
        setValue("lstartdate", leaveDetails[i][j].StartDate);
        setValue("lenddate", leaveDetails[i][j].EndDate);
        setValue("lnumberofdays", leaveDetails[i][j].NumberOfDays);
        setValue("lLeaveType", leaveDetails[i][j].LeaveType);
        setValue("lleavereason", leaveDetails[i][j].Reason);
      }
    }
  }
}

//   for (var i = 0; i < leaveDetailsById.length; i++) {
//     // if (leaveDetailsById[i].LeaveId == leaveid) {
//       setValue(
//         "lemployeeid",
//         leaveDetailsById[i].EmployeeId
//         //employeeDetails[employeeList[username]].EmployeeId
//       );
//       setValue(
//         "lemployeename",
//         employeeDetails[leaveDetailsById[i].EmployeeId].FullName
//       );
//       setValue(
//         "lleavebalance",
//         employeeDetails[leaveDetailsById[i].EmployeeId].AvailableLeave
//       );
//       setValue("lstartdate", leaveDetailsById[i].StartDate);
//       setValue("lenddate", leaveDetailsById[i].EndDate);
//       setValue("lnumberofdays", leaveDetailsById[i].NumberOfDays);
//       setValue("lLeaveType", leaveDetailsById[i].LeaveType);
//       setValue("lleavereason", leaveDetailsById[i].Reason);
//   }

if (document.getElementById("lleaveApprove") != null) {
  fillLeaveDetails();
}

if (document.getElementById("approveDenyLeaveByLeaveId") != null) {
  document.getElementById("approveDenyLeaveByLeaveId").style = "display:none;";
}

var isLeaveSelected = undefined;
function leaveSelected(leaveid, elementRef) {
  var elem = document.getElementsByClassName("borderme");
  var elements = elementRef.parentElement.childNodes;

  for (var i = 0; i < elem.length; i++) {
    elem[i].setAttribute("class", "borderme");
  }

  for (var i = 0; i < elements.length; i++) {
    elements[i].setAttribute("class", "borderme showborderme");
  }
  document.getElementById("approveDenyLeaveByLeaveId").style = "display:block;";
  selectedLeaveId = leaveid;
}
var selectedLeaveId = "";

function approveDenyLeaveById() {
  window.location.href =
    "approveLeave.html?leaveid=" +
    selectedLeaveId +
    "&username=" +
    new URLSearchParams(window.location.search).get("username");
}
