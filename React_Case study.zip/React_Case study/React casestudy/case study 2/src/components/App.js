import React from "react";
import AddRow from "./AddRow";
import DisplayRow from "./DisplayRow";
import Header from "./Header";
import { connect } from "react-redux";
import { listEmployeeAction } from "../action/employeeAction";

class App extends React.Component {
  componentDidMount() {
    this.props.dispatch(listEmployeeAction());
  }

  render() {
    let fetchJSX;
    if (this.props.fetching) {
      fetchJSX = (
        <h3 style={{ color: "blue" }}>Employee list is being fetched....</h3>
      );
    }

    console.log(this.props);
    const empJSX = this.props.employees.map(element => (
      <DisplayRow
        key={element.id}
        employee={element}
        dispatch={this.props.dispatch}
      />
    ));

    return (
      <main className="main">
        <Header />

        <section className="content">
          {fetchJSX}
          {/* <div>
            <input type="button" value="Add Employee" />
          </div> */}
          <div>
            <table id="tab">
              <thead>
                <tr>
                  <th>Id</th>
                  <th>Name</th>
                  <th>Phone</th>
                  <th>Email</th>
                  <th>Department</th>
                  <th>&nbsp;</th>
                </tr>
              </thead>

              <tbody>
                <AddRow
                  dispatch={this.props.dispatch}
                  data={this.props.idToEdit}
                />
                {empJSX[0] || this.props.fetching ? (
                  empJSX
                ) : (
                  <tr>
                    <td colSpan="6">
                      <h1 style={{ color: "maroon" }}>
                        Sorry! Unable to Fetch employee list at this point in
                        time.
                      </h1>
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </main>
    );
  }
}

function mapStateToProps(state) {
  return {
    employees: state.employees,
    fetching: state.fetching,
    error: state.error,
    idToEdit: state.idToEdit
  };
}
const AppContainer = connect(mapStateToProps)(App);
export default AppContainer;
