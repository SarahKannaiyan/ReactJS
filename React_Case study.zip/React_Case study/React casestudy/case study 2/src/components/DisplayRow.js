import React from "react";
import axios from "axios";
import {
  DeleteEmployeeAction,
  editEmployeeAction
} from "../action/employeeAction";

class DisplayRow extends React.Component {
  constructor(props) {
    super(props);
    this.editEmployee = this.editEmployee.bind(this);
  }
  editEmployee(id) {
    axios
      .get(`http://localhost:3004/departments/${id}`)
      .then(response => this.setState({ departments: response.data }))
      .catch(error => console.log("Error: ", error));
  }

  render() {
    return (
      <tr>
        <td>{this.props.employee.id}</td>
        <td>{this.props.employee.name}</td>
        <td>{this.props.employee.phone}</td>
        <td>{this.props.employee.email}</td>
        <td>{this.props.employee.department}</td>
        <td>
          <button
            className="small-button"
            onClick={() => {
              this.props.dispatch(editEmployeeAction(this.props.employee.id));
            }}
          >
            Edit
          </button>
          <button
            className="small-button"
            onClick={() => {
              this.props.dispatch(DeleteEmployeeAction(this.props.employee.id));
            }}
          >
            Delete
          </button>
        </td>
      </tr>
    );
  }
}

export default DisplayRow;
