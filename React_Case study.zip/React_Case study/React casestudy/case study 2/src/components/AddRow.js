import React from "react";
import axios from "axios";

import {
  AddEmployeeAction,
  PutEmployeeAction,
  listEmployeeAction
} from "../action/employeeAction";

class AddRow extends React.Component {
  constructor(props) {
    super(props);
    this.addEmployee = this.addEmployee.bind(this);
    this.editEmployee = this.editEmployee.bind(this);
    this.state = {
      departments: []
    };
  }
  componentDidMount() {
    axios
      .get("http://localhost:3004/departments")
      .then(response => this.setState({ departments: response.data }))
      .catch(error => console.log("Error: ", error));
  }
  addEmployee(ev) {
    const submitvalue = {
      name: this.name.value,
      phone: this.phone.value,
      email: this.email.value,
      department: this.department.value
    };

    console.log(submitvalue);

    this.props.dispatch(AddEmployeeAction(submitvalue));
    this.name.value = "";
    this.phone.value = "";
    this.email.value = "";
    this.department.value = "Select Department";
  }

  editEmployee(ev) {
    const submitvalue = {
      id: this.props.data,
      name: this.name.value,
      phone: this.phone.value,
      email: this.email.value,
      department: this.department.value
    };

    console.log(submitvalue);

    this.props.dispatch(PutEmployeeAction(submitvalue));
    this.name.value = "";
    this.phone.value = "";
    this.email.value = "";
    this.department.value = "Select Department";
    this.props.dispatch({ type: "EDIT", idToEdit: 0 });
    this.props.dispatch(listEmployeeAction());
  }

  // if (props.display === false) {
  //   return null;
  // }
  render() {
    const deptJSX = this.state.departments.map(dept => (
      <option key={dept.id}>{dept.name}</option>
    ));

    if (this.props.data !== 0) {
      axios
        .get(`http://localhost:3004/employees/${this.props.data}`)
        .then(response => {
          this.name.value = response.data.name;
          this.phone.value = response.data.phone;
          this.email.value = response.data.email;
          this.department.value = response.data.department;
        })
        .catch(error => console.log("Error: ", error));
    }

    let conditionalEditJSX = (
      <div>
        <button className="small-button" onClick={this.addEmployee}>
          Add
        </button>
        {/* <button className="small-button" onClick={this.editEmployee}>
          Modify
        </button> */}
      </div>
    );
    if (this.props.data !== 0) {
      conditionalEditJSX = (
        <div>
          <button className="small-button" onClick={this.editEmployee}>
            Modify
          </button>
        </div>
      );
    }

    // if (this.props.data == undefined) {
    //   alert("test");
    // } else {
    //   alert("test1");
    // }
    return (
      <tr style={{ backgroundColor: "lightpink" }}>
        <td>&nbsp;</td>
        <td>
          <input
            size="10"
            placeholder="enter name"
            ref={node => (this.name = node)}
          />
        </td>
        <td>
          <input
            size="10"
            placeholder="enter phone"
            ref={node => (this.phone = node)}
          />
        </td>
        <td>
          <input
            size="10"
            placeholder="enter email"
            ref={node => (this.email = node)}
          />
        </td>
        <td>
          <select ref={node => (this.department = node)}>
            <option>Select Department</option>
            {/* <option>Select Department</option>
            <option>Finance</option>
            <option>Human Resources</option>
            <option>Learning &amp; Development</option> */}
            {deptJSX}
          </select>
        </td>
        <td>{conditionalEditJSX}</td>
      </tr>
    );
  }
}

// AddRow.defaultProps = {
//   display: false
// };
export default AddRow;
