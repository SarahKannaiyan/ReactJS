function employeeReducer(
  prevState = {
    fetching: false,
    employees: [],
    error: "",
    idToEdit: 0
  },
  action
) {
  let newState;
  switch (action.type) {
    case "EDIT":
      newState = {
        ...prevState,
        fetching: false,
        idToEdit:
          action.employees === undefined
            ? action.idToEdit
            : action.employees.id,
        error: ""
      };
      break;
    case "FETCHING":
      newState = { ...prevState, fetching: true, employees: [], error: "" };
      break;
    case "FETCH_SUCCESS":
      newState = {
        ...prevState,
        fetching: false,
        employees: action.employees,
        error: ""
      };
      break;
    case "FETCH_ERROR":
      newState = {
        ...prevState,
        fetching: false,
        employees: [],
        error: action.error
      };
      break;

    default:
      newState = { ...prevState };
      break;
  }
  return newState;
}

export default employeeReducer;

// store =
// {
//     fetching: false,
//      employees: [
//         {
//           "id": 1,
//           "name": "Vijay",
//           "email": "test@test.com",
//           "phone": "1234567890",
//           "department": "Learning & Development"
//         }
//     ,error:''
//     }

//     {type:'FETCHING'}
//     {type:'FETCH_SUCCESS',employees:[{id:1,name:'ssss'},{id:2,name:'aaa'}]}
//     {type:'FETCH_ERROR',error:''}
