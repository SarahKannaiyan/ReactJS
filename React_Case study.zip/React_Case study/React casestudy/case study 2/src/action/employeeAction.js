import axios from "axios";

export function listEmployeeAction() {
  return function(dispatch) {
    dispatch({ type: "FETCHING" });
    axios
      .get("http://localhost:3004/employees")
      .then(response =>
        dispatch({
          type: "FETCH_SUCCESS",
          employees: response.data
        })
      )
      .catch(error =>
        dispatch({
          type: "FETCH_ERROR",
          error: error.message
        })
      );
  };
}

export function AddEmployeeAction(emp) {
  return function(dispatch) {
    axios
      .post("http://localhost:3004/employees", emp)
      .then(response => dispatch(listEmployeeAction()))
      .catch(error => console.log("Error ", error));
  };
}

export function DeleteEmployeeAction(id) {
  return function(dispatch) {
    axios
      .delete(`http://localhost:3004/employees/${id}`)
      .then(response => dispatch(listEmployeeAction()))
      .catch(error => console.log("Error ", error));
  };
}

export function PutEmployeeAction(data) {
  return function(dispatch) {
    axios
      .put(`http://localhost:3004/employees/${data.id}`, data)
      .then(response => {
        dispatch({ type: "EDIT", idToEdit: 0 });
      })
      .then(response => dispatch(listEmployeeAction()))
      .catch(error => console.log("Error ", error));
  };
}

export function editEmployeeAction(id) {
  return function(dispatch) {
    axios
      .get(`http://localhost:3004/employees/${id}`)
      //.then(response => dispatch(listEmployeeAction()))
      .then(response => dispatch({ type: "EDIT", employees: response.data }))
      .catch(error => console.log("Error ", error));
  };

  // return function(dispatch) {
  //   dispatch({ type: "FETCHING" });
  //   axios
  //     .get("http://localhost:3004/employees")
  //     .then(response =>
  //       dispatch({
  //         type: "FETCH_SUCCESS",
  //         employees: response.data
  //       })
  //     )
  //     .catch(error =>
  //       dispatch({
  //         type: "FETCH_ERROR",
  //         error: error.message
  //       })
  //     );
  // };
}
