import React from "react";
//import { incrementHandler, decrementHandler } from "../actions/counterActions";

class Form extends React.Component {
  // constructor(props) {
  //   super(props);

  //   this.increment = this.increment.bind(this);
  //   this.decrement = this.decrement.bind(this);
  // }

  // increment() {
  //   console.log("incrementing...");
  //   this.props.incrHandler();
  //   //this.props.dispatch(incrementHandler());
  // }
  // decrement() {
  //   console.log("decrementing...");
  //   this.props.decrHandler();
  //   //this.props.dispatch(decrementHandler());
  // }
  render() {
    return (
      <form>
        <input
          type="button"
          value="Increment"
          onClick={() => {
            this.props.incrHandler();
          }}
        />
        &nbsp;&nbsp;
        <input
          type="button"
          value="Decrement"
          onClick={() => {
            this.props.decrHandler();
          }}
        />
      </form>
    );
  }
}

export default Form;
