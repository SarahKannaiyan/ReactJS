import React from "react";

class UserDetails extends React.Component {
  render() {
    console.log("US props: ", this.props);

    const { fetching, details, error } = this.props;
    let fetchJSX = null,
      errorJSX = null,
      userDetailsJSX = null;

    if (fetching) {
      fetchJSX = (
        <h3 style={{ color: "blue" }}>
          Please wait...Details are being fetched.
        </h3>
      );
    }

    if (error) {
      errorJSX = <h3 style={{ color: "red" }}>{error}</h3>;
    }

    if (details) {
      userDetailsJSX = (
        <ul>
          <li>
            <strong>Name:</strong>
            {details.name}
          </li>
          <li>
            <strong>Location:</strong>
            {details.location}
          </li>
          <li>
            <strong>Company:</strong>
            {details.company}
          </li>
        </ul>
      );
    }

    return (
      <div>
        <form>
          {fetchJSX}
          {errorJSX}
          <input
            size="40"
            type="text"
            defaultValue="https://api.github.com/users/gaeron"
          />

          <input
            type="button"
            defaultValue="Get User Details..."
            onClick={() => {
              //todo
              this.props.userDetailsHandler(this.url);
            }}
          />
          {/* <input
            type="button"
            defaultValue="Get User Details..."
            onClick={node => {
              this.url = node;
            }}
          /> */}
        </form>
        {userDetailsJSX}
      </div>
    );
  }
}

export default UserDetails;
