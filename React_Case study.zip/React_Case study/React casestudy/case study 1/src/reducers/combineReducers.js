import { combineReducers } from "redux";

import counterReducer from "./counterReducer";
import userDetailsReducer from "./userDetailsReducer";

const cr = combineReducers({
  counter: counterReducer,
  user: userDetailsReducer
});
export default cr;
