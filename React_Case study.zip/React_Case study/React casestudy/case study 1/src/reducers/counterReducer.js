function counterReducer(previousState = { count: 0 }, action) {
  let newState;
  switch (action.type) {
    case "INCREMENT":
      newState = { ...previousState, count: previousState.count + 1 };
      break;
    case "DECREMENT":
      newState = { ...previousState, count: previousState.count - 1 };
      break;

    default:
      newState = { ...previousState };
      break;
  }
  // console.log("prevState: ", previousState);
  // console.log("action: ", action);
  // console.log("newState: ", newState);
  // console.log("--------------");
  return newState;
}

export default counterReducer;
