import React from "react";
import ReactDOM from "react-dom";
import { createStore, applyMiddleware } from "redux";
import { Provider } from "react-redux";
import App from "./components/App";
//import counterReducer from "./reducers/counterReducer";
import { composeWithDevTools } from "redux-devtools-extension";
import customLogger from "./middleware/customLogger";
import logger from "redux-logger";
import thunk from "redux-thunk";
import combineReducers from "./reducers/combineReducers";

//const spaStore = createStore(counterReducer, composeWithDevTools());
//const spaStore = createStore(counterReducer, applyMiddleware(logger));
const spaStore = createStore(
  combineReducers,
  composeWithDevTools(applyMiddleware(thunk, logger))
);

ReactDOM.render(
  <Provider store={spaStore}>
    <App />
  </Provider>,
  document.getElementById("root")
);
