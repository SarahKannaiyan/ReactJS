// function customLogger(store) {
//   return function(next) {
//     return function(action) {
//       console.log("prevState: ", store.getState());
//       console.log(action);
//       next(action);
//       console.log("newState: ", store.getState());
//       console.log("------------------------");
//     };
//   };
// }
const customLogger = store => next => action => {
  console.log("prevState: ", store.getState());
  console.log(action);
  next(action);
  console.log("newState: ", store.getState());
  console.log("------------------------");
};

export default customLogger;
