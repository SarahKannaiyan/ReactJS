import axios from "axios";

function fetchUserDetailsAction(url) {
  return function(dispatch) {
    dispatch({ type: "FETCHING" });
    axios
      .get(url)
      .then(function(response) {
        dispatch({ type: "FETCH_SUCCESS", details: response.data });
        console.log(response);
      })
      .catch(function(error) {
        dispatch({ type: "FETCH_ERROR", error: error.message });
      });
  };
}

export default fetchUserDetailsAction;
