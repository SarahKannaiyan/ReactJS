export function incrementHandler() {
  return { type: "INCREMENT" };
}

export function decrementHandler() {
  return { type: "DECREMENT" };
}
