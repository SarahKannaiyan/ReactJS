import { connect } from "react-redux";
import Form from "../components/Form";
import { incrementHandler, decrementHandler } from "../actions/counterActions";

function mapStateToProps(state) {
  return {};
}

function mapDispathToProps(dispatch) {
  return {
    incrHandler: () => dispatch(incrementHandler()),
    decrHandler: () => dispatch(decrementHandler())
  };
}

let FormContainer = connect(
  mapStateToProps,
  mapDispathToProps
)(Form);
export default FormContainer;
