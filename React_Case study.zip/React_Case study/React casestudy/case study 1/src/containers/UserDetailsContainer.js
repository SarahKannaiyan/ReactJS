import { connect } from "react-redux";
import UserDetails from "../components/UserDetails";
import fetchUserDetailsAction from "../actions/userDetailsAction";

function mapStateToProps(state) {
  return {
    fetching: state.user.fetching,
    details: state.user.details,
    error: state.user.error
  };
}

function mapDispatchToProps(dispatch) {
  return {
    userDetailsHandler: url => {
      dispatch(fetchUserDetailsAction(url));
    }
  };
}
const UserDetailsContainer = connect(
  mapStateToProps,
  mapDispatchToProps
)(UserDetails);
export default UserDetailsContainer;
