import React from "react";

class Nav extends React.Component {
  render() {
    return (
      <nav class="nav">
        <div>
          <a href="#">Department</a>
        </div>
        <div>
          <a href="#">Employee</a>
        </div>
        <div>
          <a href="#">Logout</a>
        </div>
      </nav>
    );
  }
}

export default Nav;
