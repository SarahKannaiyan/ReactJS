import React from "react";
import { connect } from "react-redux";

import { incrementAction, decrementAction } from "../actions/counterActions";

class Form extends React.Component {
  constructor(props) {
    super(props);
    this.incrementHandler = this.incrementHandler.bind(this);
    this.decrementHandler = this.decrementHandler.bind(this);
  }

  incrementHandler() {
    console.log("incrementing...");

    this.props.dispatch(incrementAction());
  }

  decrementHandler() {
    console.log("decrementing...");

    this.props.dispatch(decrementAction());
  }

  render() {
    console.log("Form Props: ", this.props);
    return (
      <form>
        <input
          type="button"
          value="Increment"
          onClick={this.incrementHandler}
        />
        &nbsp;&nbsp;&nbsp;
        <input
          type="button"
          value="Decrement"
          onClick={this.decrementHandler}
        />
      </form>
    );
  }
}
const FormContainer = connect()(Form);

export default FormContainer;
