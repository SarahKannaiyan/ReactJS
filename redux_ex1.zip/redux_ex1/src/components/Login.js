import React from "react";

this.state = {
  un: "",
  pwd: ""
};

this.unChanged = this.unChanged.bind(this);

export default Login;
