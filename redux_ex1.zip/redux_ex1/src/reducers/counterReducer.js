import React from "react";

function counterReducer(prevState = { count: 0 }, action) {
  let newState;
  switch (action.type) {
    case "INCREMENT":
      newState = { ...prevState, count: prevState.count + 1 };
      break;
    case "DECREMENT":
      newState = { ...prevState, count: prevState.count - 1 };
      break;
    default:
      newState = { ...prevState };
      break;
  }

  console.log("prevState: ", prevState);
  console.log("action: ", action);
  console.log("newState: ", newState);
  console.log("............................................");

  return newState;
}

export default counterReducer;
