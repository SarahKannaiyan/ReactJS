function getAction(choice) {
    var isAudioVideo="";
    if(document.getElementById('rdVideo').checked){
        isAudioVideo = 'vid';
    }
    if(document.getElementById('rdAudio').checked){
        isAudioVideo = 'aud';
    }
    
    switch (choice) {
        case 'play':
            document.getElementById(isAudioVideo).play();
            break;
        case 'pause':
            document.getElementById(isAudioVideo).pause();
            break;
        case 'stop':
        document.getElementById(isAudioVideo).pause();
        document.getElementById(isAudioVideo).currentTime =  0;
            break;
        case 'loop':
            document.getElementById(isAudioVideo).loop = true;
            break;
        case 'seek':
        var currentTime = document.getElementById(isAudioVideo).currentTime;
        document.getElementById(isAudioVideo).currentTime =  currentTime + 10;
            break;
        default:            
            break;
    }


}