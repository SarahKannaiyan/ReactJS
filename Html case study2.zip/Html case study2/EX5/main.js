
var canvas = document.getElementById('ellipsis');
var context = canvas.getContext('2d');


context.fillStyle = 'rgba(255,0,0,0.5)';
context.beginPath();
context.ellipse(100, 100, 25, 75, 45 * Math.PI / 90, 0, 2 * Math.PI);
context.strokeStyle = 'rgba(255,0,0,0.5)';
context.stroke();
context.closePath();
context.fill();


context.fillStyle = 'rgba(0,255,0,0.5)';
context.beginPath();
context.lineWidth = 2;
context.ellipse(100, 100, 25, 75, 45 * Math.PI / 180, 0, 2 * Math.PI);
context.strokeStyle = 'rgba(0,255,0,0.5)';
context.stroke();
context.closePath();
context.fill();

context.fillStyle = 'rgba(0,0,255,0.5)';
context.beginPath();
context.ellipse(100, 100, 25, 75, -45 * Math.PI / 180, 0, 2* Math.PI);
context.strokeStyle = 'rgba(0,0,255,0.5)';
context.stroke();
context.closePath();
context.fill();



