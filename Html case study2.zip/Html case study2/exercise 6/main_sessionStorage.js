/**
 * @author Prakash Kumar
 */
function welcome(){
    if (sessionStorage.getItem('firstname') != undefined) {
        alert("Welcome " + sessionStorage.getItem('firstname')+' '+sessionStorage.getItem('lastname'));
    }
    else
    {
        alert("Welcome Guest, you are visiting first time!!!");
    }
}

function callMe(){
    if (sessionStorage.getItem('firstname') == undefined) {
        document.getElementById('visitorcount').innerHTML = '0';
    }
    else {
        document.getElementById('storedname').value = sessionStorage.getItem('firstname')+' '+sessionStorage.getItem('lastname');
        document.getElementById('visitorcount').innerHTML = sessionStorage.getItem('visitorcount');
    }
}
callMe();
function submitvalues() {
    sessionStorage.setItem('firstname', document.getElementById('firstname').value);
    sessionStorage.setItem('lastname', document.getElementById('lastname').value);

    if (sessionStorage.getItem('visitorcount') == undefined) {
        sessionStorage.setItem('visitorcount', 1);
    }
    else {
        sessionStorage.setItem('visitorcount', parseInt(sessionStorage.getItem('visitorcount')) + 1);
    }
    callMe();
}

function resetvalues() {
    sessionStorage.removeItem('visitorcount');
    sessionStorage.removeItem('firstname');
    sessionStorage.removeItem('lastname');
    callMe();
}