/**
 * @author Prakash Kumar
 */
function welcome(){
    if (localStorage.getItem('firstname') != undefined) {
        alert("Welcome " + localStorage.getItem('firstname')+' '+localStorage.getItem('lastname'));
    }
    else
    {
        alert("Welcome Guest, you are visiting first time!!!");
    }
}

function callMe(){
    if (localStorage.getItem('firstname') == undefined) {
        document.getElementById('visitorcount').innerHTML = '0';
    }
    else {
        document.getElementById('storedname').value = localStorage.getItem('firstname')+' '+localStorage.getItem('lastname');
        document.getElementById('visitorcount').innerHTML = localStorage.getItem('visitorcount');
    }
}
callMe();
function submitvalues() {
    localStorage.setItem('firstname', document.getElementById('firstname').value);
    localStorage.setItem('lastname', document.getElementById('lastname').value);

    if (localStorage.getItem('visitorcount') == undefined) {
        localStorage.setItem('visitorcount', 1);
    }
    else {
        localStorage.setItem('visitorcount', parseInt(localStorage.getItem('visitorcount')) + 1);
    }
    callMe();
}

function resetvalues() {
    localStorage.removeItem('visitorcount');
    localStorage.removeItem('firstname');
    localStorage.removeItem('lastname');
    callMe();
}