function welcome(){
    if (localStorage.getItem('firstname') != undefined) {       
        document.getElementById('welcomemessage').innerHTML = "Welcome " + localStorage.getItem('firstname')+' '+localStorage.getItem('lastname');
    }
    else
    {        
        document.getElementById('welcomemessage').innerHTML ="Welcome Guest, you are visiting first time!!!" 
    }
}

function submitvalues() {
    localStorage.setItem('firstname', document.getElementById('firstname').value);
    localStorage.setItem('lastname', document.getElementById('lastname').value);    
    if (localStorage.getItem('visitorcount') == undefined) {
        localStorage.setItem('visitorcount', 1);
    }
    else {
        localStorage.setItem('visitorcount', parseInt(localStorage.getItem('visitorcount'))+1);
    }
    increaseVisitorCount();
    welcome();
}
function resetvalues() {
    localStorage.clear();
    increaseVisitorCount();
    document.getElementById('firstname').value ="";
    document.getElementById('lastname').value ="";
    document.getElementById('storedname').value ="";
    welcome();
}

function increaseVisitorCount(){
    if (localStorage.getItem('firstname') == undefined) {
        document.getElementById('visitorcount').innerHTML = '0';
    }
    else {
        document.getElementById('storedname').value = localStorage.getItem('firstname')+' '+localStorage.getItem('lastname');
        document.getElementById('visitorcount').innerHTML = localStorage.getItem('visitorcount');
    }
}