function welcome(){
    if (sessionStorage.getItem('firstname') != undefined) {       
        document.getElementById('welcomemessage').innerHTML = "Welcome " + sessionStorage.getItem('firstname')+' '+sessionStorage.getItem('lastname');
    }
    else
    {        
        document.getElementById('welcomemessage').innerHTML ="Welcome Guest, you are visiting first time!!!" 
    }
}

function submitvalues() {
    sessionStorage.setItem('firstname', document.getElementById('firstname').value);
    sessionStorage.setItem('lastname', document.getElementById('lastname').value);    
    if (sessionStorage.getItem('visitorcount') == undefined) {
        sessionStorage.setItem('visitorcount', 1);
    }
    else {
        sessionStorage.setItem('visitorcount', parseInt(sessionStorage.getItem('visitorcount'))+1);
    }
    increaseVisitorCount();
    welcome();
}
function resetvalues() {
    sessionStorage.clear();
    increaseVisitorCount();
    document.getElementById('firstname').value ="";
    document.getElementById('lastname').value ="";
    document.getElementById('storedname').value ="";
    welcome();
}

function increaseVisitorCount(){
    if (sessionStorage.getItem('firstname') == undefined) {
        document.getElementById('visitorcount').innerHTML = '0';
    }
    else {
        document.getElementById('storedname').value = sessionStorage.getItem('firstname')+' '+sessionStorage.getItem('lastname');
        document.getElementById('visitorcount').innerHTML = sessionStorage.getItem('visitorcount');
    }
}