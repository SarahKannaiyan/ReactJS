/**
 * @author Prakash Kumar
 */
function action(choice) {
    var isAudioOrVid="";
    if(document.getElementById('rdVideo').checked){
        isAudioOrVid = 'vid';
    }
    if(document.getElementById('rdAudio').checked){
        isAudioOrVid = 'aud';
    }
    
    switch (choice) {
        case 'play':
            document.getElementById(isAudioOrVid).play();
            break;
        case 'pause':
            document.getElementById(isAudioOrVid).pause();
            break;
        case 'stop':
        document.getElementById(isAudioOrVid).pause();
        document.getElementById(isAudioOrVid).currentTime =  0;
            break;
        case 'loop':
            document.getElementById(isAudioOrVid).loop = true;
            break;
        case 'seek':
        var currentTime = document.getElementById(isAudioOrVid).currentTime;
        document.getElementById(isAudioOrVid).currentTime =  currentTime + 10;
            break;
        default:
            alert('choose something')
            break;
    }

}